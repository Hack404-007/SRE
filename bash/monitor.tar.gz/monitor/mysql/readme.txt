
##readme.txt
## monitor mysql error & performance
##1. add mysql user
###在mysql中增加权限
##grant SUPER,SHOW DATABASES,REPLICATION SLAVE,PROCESS,REPLICATION CLIENT on *.* to 'monitor'@'localhost' identified by 'monitor@mysql'
#2. create centos user zabbix:zabbix
#3. install zabbix agentd in /usr/local/zabbix
#4.部署路径 /data/zabbix/monagent/
#5.*.sh文件中ServerActive=zabbix server ip 
##add crontab 
yum install -y  perl-DBD-MySQL
crontab -l -u root > /tmp/crontab.tmp
echo "" >> /tmp/crontab.tmp
echo "#mysql error monitor jet `date +%F`" >>  /tmp/crontab.tmp
echo "*/5 * * * * /usr/local/monagent/mysql/mysql_err_monitor.sh >/usr/local/monagent/mysql/mysql_err_monitor.log 2>&1" >>  /tmp/crontab.tmp

echo "" >> /tmp/crontab.tmp
echo "#mysqlreport zabbix jet `date +%F`"  >>  /tmp/crontab.tmp
echo "*/5 * * * * /usr/local/monagent/mysql/mysql_report_zabbix.sh >/usr/local/monagent/mysql/mysql_report_zabbix.log 2>&1" >>  /tmp/crontab.tmp

crontab /tmp/crontab.tmp -u root && rm -f /tmp/crontab.tmp

##modify conf
