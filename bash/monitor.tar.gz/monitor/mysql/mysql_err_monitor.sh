#! /bin/sh
export PATH='/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin'
###主要是监控Mysql相关，如有异常进行告警.判断mysql相关根据参数my.cnf提取相关信息.
#目前主要检测
#1.mysql是否运行.
#2.错误信息,如果错误条数大于3条，计算总错误记录行数。发送
#3.slave db，检测同步是否正常，如果异常告警
##在mysql中增加权限
##grant SUPER,SHOW DATABASES,REPLICATION SLAVE,PROCESS,REPLICATION CLIENT on *.* to 'monitor'@'localhost' identified by 'monitor@mysql'

###通过zabbix上报。同时如果是slave的话，上报slave的同步延迟点.

##收集信息并上报
function f_send_msg()
{
  warninfo=$1 
  hourstr=`date +%H:%M:%S` 
  hostname="`hostname`"
  telmsg="主机${hostname}(${ip}):${warninfo}"
  #tellst="13682410360,15813839689,18938922248,13798267966"
  #tellst="13798267966"    
  ##增加一个告警开关阀值,如果为Y，则进行发送告警。否则不发送.  
 # if [ "${msgflag}" = "Y" ]; then
  	#sendstra="curl -d 't=${tellst}&c=${telmsg}' http://117.135.141.95:8080/sendsms"
    #echo $sendstra
    #eval "$sendstra"
    
 #   echo "`date`  发送人:${tellst} ${telmsg} " >>  ${warnfile}
 #   echo  "`date`  ${telmsg} " 
 # else
    echo "`date` ${telmsg} " >>  ${warnfile} 
    echo "`date` ${telmsg} "
 # fi
}

##得到本机IP
function f_get_localip()
{
  ##获取本机IP
  ethnum=`/sbin/ifconfig|grep eth|wc -l`
  if [ ${ethnum} -gt 1 ]; then
    ip_inner=`/sbin/ifconfig eth1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
  else
    ethname=`/sbin/ifconfig|grep eth|awk '{print $1}'|sed 's/^ //;s/ $//;s/[[:space:]]*//g'`
    ip_inner=`/sbin/ifconfig ${ethname} 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
  fi
  ip=${ip_inner}
}
##根据传入的my.cnf文件来提取相关文件及路径信息
##2011-02-14增加参数校验,如只能是slave或者master
function f_set_parmeter()
{
  local monlst="$1"
  ##DBBASE1 | /etc/my.cnf  | /tmp/mysql.sock | root     | rootpwd  | Y    | slave | auto | 300
  #echo "INPUT: ###${monlst}###"
  mysql_profile=`echo ${monlst} |awk -F"|" '{print $2}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysqlsock=`echo ${monlst}     |awk -F"|" '{print $3}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysquser=`echo ${monlst}      |awk -F"|" '{print $4}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysqlpwd="`echo ${monlst}     |awk -F"|" '{print $5}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'`" 
  msgflag=`echo ${monlst}       |awk -F"|" '{print $6}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysqlroletmp=`echo ${monlst}  |awk -F"|" '{print $7}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  slaveauto=`echo ${monlst}     |awk -F"|" '{print $8}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  delaynum=`echo ${monlst}      |awk -F"|" '{print $9}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  slowfile=`echo ${monlst}      |awk -F"|" '{print $10}'|sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  ####################################
  ##echo  "hello world" | tr "[a-z]" "[A-Z]"  
  #echo "##mysql_profile=$mysql_profile mysqlsock=$mysqlsock mysquser=$mysquser mysqlpwd=$mysqlpwd ${msgflag}#  ${mysqlroletmp} ${slaveauto} ${delaynum}" 
  mysqlrole=`echo "${mysqlroletmp}" | tr "[a-z]" "[A-Z]"`  
  if [ "${mysqlrole}" != "SLAVE" -a "${mysqlrole}" != "MASTER" ]; then 
     Errinfo="配置选项中的DB类型配置错误,只能为master或slave,当前配置为${mysqlroletmp},请修改."
     echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${Errinfo}">>${DATA_FILE}
     f_send_msg "${Errinfo}" 
      ##上报
      send_msg_zabbix 
     exit 1
  fi
    
  if [ ! -f ${mysql_profile} ]; then
    Errinfo="配置参数${mysql_profile}对应文件无法找到,请检查"
    echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${Errinfo}">>${DATA_FILE}   
    f_send_msg "${Errinfo}"
    ##上报
    send_msg_zabbix  
    exit 1
  fi
  ##检查参数是否已经在参数文件配置.
  paranum=`cat ${mysql_profile} |grep -w "^basedir"|wc -l`
  if [ ${paranum} -gt 1 ]; then
    Errinfo="${mysql_profile}文件中参数basedir配置有误,存在个数${paranum}，请检查配置正确." 
    echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${Errinfo}">>${DATA_FILE} 
    f_send_msg "${Errinfo}" 
    ##上报
    send_msg_zabbix 
    exit 1
  elif [ ${paranum} -eq 0 ]; then
     mysqldir="/usr/local/mysql"
  else
     mysqldir=`cat ${mysql_profile} |grep -w "^basedir"|awk -F"=" '{print $2}' | sed 's/^ //;s/ $//'`
  fi		
  ##由于my.cnf中会配置客户端和server端都有socket配置。故暂时无法区分。
  #mysqlsock=`cat ${mysql_profile} |grep -w "^socket"|awk -F"=" '{print $2}' | sed 's/^ //;s/ $//'`
  if [ "${mysqlpwd}" = "" ]; then
    mysqluserpwd=""
  else
    mysqluserpwd="-p${mysqlpwd}"
  fi
  ##如果没有设置最大告警延迟值，则默认为999999
  if [ "${delaynum}" = "" ]; then
    delaynum=999999
  fi
  if [ "$slaveauto" = "" ]; then
     slaveauto="no"
  fi
  ##检查mysql运行是否正常.
  testrst=`${mysqldir}/bin/mysql -u${mysquser} ${mysqluserpwd} -S ${mysqlsock} -s -e "select 1;"`
  if [ "${testrst}" != "1" ]; then
    msginfo="mysql无法登录执行,请检查是否已经启动或者配置错误."
    echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE}
    f_send_msg "${msginfo}" 
    ##上报
    send_msg_zabbix  
    exit 1
  fi
####################提取参数信息.	
  mysqldatadir=`${mysqldir}/bin/mysql -u${mysquser} ${mysqluserpwd} -S ${mysqlsock} -s -e "SHOW VARIABLES like 'datadir'"|awk '{print $2}' | sed 's#/$##'`
  if [ "${mysqldatadir}" = "" ]; then
    msginfo="mysql 可能已经shutdown,or 连接mysql的帐号,密码,socket没有配置正确,请检查参数"
    echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE} 
    f_send_msg "${msginfo}"  
    ##上报
    send_msg_zabbix
    exit 1
  fi
  mysqllogfile=`${mysqldir}/bin/mysql -u${mysquser} ${mysqluserpwd} -S ${mysqlsock} -s -e "SHOW VARIABLES like 'log_error'" | awk '{print $2}'`
  if [ "${mysqllogfile}" = "" ]; then
    mysqllogfile="${mysqldatadir}/`hostname`.err"
  fi
if [ ! -f ${mysqllogfile} ]; then
  msginfo="${mysqllogfile}文件不存在，请检查是否修改了主机名或者配置错误."
  echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE} 
  f_send_msg "${msginfo}" 
  ##上报
  send_msg_zabbix
  exit 1
fi

if [ "${slowfile}" != "" ]; then
#  slow_flag=`${mysqldir}/bin/mysql -u${mysquser} ${mysqluserpwd} -S ${mysqlsock} -s -e "SHOW VARIABLES like 'log_slow_queries'"|awk '{print $2}'`
  slow_flag=`${mysqldir}/bin/mysql -u${mysquser} ${mysqluserpwd} -S ${mysqlsock} -s -e "SHOW VARIABLES like 'slow_query_log'"|awk '{print $2}'`
  if [ "$slow_flag" = "ON" ]; then
    monslow_file=${mysqldatadir}/${slowfile} 
    if [ ! -f ${monslow_file} ]; then
      msginfo="${monslow_file}文件不存在，请检查慢速SQL配置项是否正确."
      echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE} 
      f_send_msg "${msginfo}" 
      monslow_file=""
    fi
  else
      msginfo="该DB未开启慢速SQL监控,却配置了提取慢速SQL,请检查DB配置项."
      echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE} 
      f_send_msg "${msginfo}"
      monslow_file=""  
  fi
fi

#mysqlslow=`cat ${mysql_profile} |grep -w "^log_slow_queries"|awk -F"=" '{print $2}' | sed 's/^ //;s/ $//'`			
}

#判断Mysql 同步是否正常
function f_slave_status()
{
########################################################################################
##
##脚本名:Mysql Slave 状态监控
##  说明:如果Slave_IO_Running和Slave_SQL_Running全部为No,我们认为是人为的slave stop了
##
########################################################################################
mysqldir=$1
dbuser=$2
dbpwd=$3
socket=$4
autoFix=$5
maxdelaynum=$6
slvstatus=`${mysqldir}/bin/mysql -u"$dbuser" $dbpwd -S $socket -e "show slave status \G"|egrep  "Slave_IO_Running:|Slave_SQL_Running:|Seconds_Behind_Master"`
rstcode=$?
##为空可能是master或者单机情况.
if [ "${slvstatus}" = "" ]; then
  msginfo="Mysql同步检测配置错误,请检查配置!"
  echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE} 
  f_send_msg "${msginfo}"   
  return 1
fi
if [ ${rstcode} -ne 0 ]; then
  msginfo="执行检查Mysql同步命令异常,返回${rstcode}，请检查"
  echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE}   
  f_send_msg "${msginfo}" 
  return 1
fi

Slave_IO_Running=`echo      "${slvstatus}"|grep "Slave_IO_Running"     |sed s/"Slave_IO_Running:"//g|sed s/' '//g`
Slave_SQL_Running=`echo     "${slvstatus}"|grep "Slave_SQL_Running"    |sed s/"Slave_SQL_Running:"//g|sed s/' '//g`
Seconds_Behind_Master=`echo "${slvstatus}"|grep "Seconds_Behind_Master"|sed s/"Seconds_Behind_Master:"//g|sed s/' '//g`
##执行成功，方式相关值上报给zabbix.
echo "${ZABBIX_NAME} mysql.slave.io.running ${Slave_IO_Running}">>${DATA_FILE} 
echo "${ZABBIX_NAME} mysql.slave.sql.running ${Slave_SQL_Running}">>${DATA_FILE}
echo "${ZABBIX_NAME} mysql.slave.Seconds.behind.master ${Seconds_Behind_Master}">>${DATA_FILE}
msginfo="mysql.slave.Seconds.behind.master=${Seconds_Behind_Master}"
f_send_msg "${msginfo}" 
msginfo="Slave_IO_Running=${Slave_IO_Running} Slave_SQL_Running=${Slave_SQL_Running}"
f_send_msg "${msginfo}"
	
if [ "$Slave_IO_Running" = "No" -a "$Slave_SQL_Running" = "No" ]; then
  msginfo="Mysql同步异常,可能手工停止,不做自动修复."
  echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE}
  f_send_msg "${msginfo}" 
elif [ "$Slave_IO_Running" = "No" -o "$Slave_SQL_Running" = "No" ]; then
	  
  if [ -n "$autoFix" -a "$autoFix" = "auto" ]; then     
    ${mysqldir}/bin/mysql -u"$dbuser" $dbpwd -S $socket -e "slave start;"
    sleep 5 
    slvstatus=`${mysqldir}/bin/mysql -u"$dbuser" $dbpwd -S $socket -e "show slave status \G"|egrep  "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master"`
    Slave_IO_Running=`echo      "${slvstatus}"|grep "Slave_IO_Running"     |sed s/"Slave_IO_Running:"//g|sed s/' '//g`
    Slave_SQL_Running=`echo     "${slvstatus}"|grep "Slave_SQL_Running"    |sed s/"Slave_SQL_Running:"//g|sed s/' '//g`
    if [ "$Slave_IO_Running" = "No" -o "$Slave_SQL_Running" = "No" ]; then
    	msginfo="Mysql同步异常,自动修复失败，请尽快检查." 
    	echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE}
    	f_send_msg "${msginfo}" 
    else    
      msginfo="Mysql同步异常，已经自动修复." 
      echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE}
      f_send_msg "${msginfo}" 
    fi   
  else
    msginfo="Mysql同步异常,未配置自动修复,请尽快处理."
    echo "{ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE} 
    f_send_msg "${msginfo}" 
  fi
else  
  if [ "$Seconds_Behind_Master" != "NULL" -a $Seconds_Behind_Master -gt ${maxdelaynum} -a "${maxdelaynum}" != "" ]; then
     msginfo="Mysql同步延迟${Seconds_Behind_Master}超过阀值${maxdelaynum}"
     echo "${ZABBIX_NAME} mysql.slave.conf.err.info ${msginfo}">>${DATA_FILE}
     f_send_msg "${msginfo}" 
  fi 	
fi 
}

function f_mysql_errinfo()
{
logfile=$1
errrule=$2
#>$mysql_error_log
########################################################################################
##
##脚本名:MySQL 错误信息监控
##  说明:定时监控MySQL的错误日志
##       先用diff判断两个文件是否有差别,通过diff的返回值,1有,0没有
##       如果有差异就用comm输出差异信息,comm不论有差异没差异,返回都是0,真BT
##       awk -F "[ERROR]" 不能被接受,所以只有awk -F "ERROR]"
##如果第一次执行，生成bak文件即可，其它不做处理.
#errrule规则如："mysqld ended|shut down|mysqld restarted"
########################################################################################
baklogfile=${logfile}.err_bak
if [ ! -f ${baklogfile} ]; then
  cp ${logfile} ${baklogfile}
  return 0
fi	
##判断如果日志文件记录为空，则不进行处理.
lognum=`cat ${logfile} |wc -l`
if [ ${lognum} -eq 0 ]; then
	cp ${logfile} ${baklogfile}
  return 0
fi
##进行处理.
diff  ${logfile} ${baklogfile}  >/dev/null
if [ $? = 1 ]; then
 # comm -3 ${logfile} ${baklogfile}|grep ERROR|awk -F "ERROR]" '{print $2}' >/tmp/mysql_tmp_error
  comm -3 ${logfile} ${baklogfile}|grep ERROR  >/tmp/mysql_tmp_error
  ##匹配规则  
  if [ "${errrule}z" = "z" ]; then
    comm -3 ${logfile} ${baklogfile}|grep -E "mysqld ended|shut down|mysqld restarted" >> /tmp/mysql_tmp_error
  else
    comm -3 ${logfile} ${baklogfile}|grep -E "${errrule}" >> /tmp/mysql_tmp_error
  fi
  ##每次判断错误或者告警记录数，如果超过3个就只告警总数，2条以内就告警具体内容。避免骚扰.
  ##有错误只发一次，并发送记录条数
  maxnum=1
  sed -i -r /^$/d  /tmp/mysql_tmp_error
  infonum=`cat /tmp/mysql_tmp_error|wc -l`
  if [ ${infonum} -gt 0 ]; then
    msginfotmp="`cat /tmp/mysql_tmp_error |head -1`"
    msginfo="Mysql错误或告警记录数${infonum}条,具体为:${msginfotmp}等,请尽快查看并解决"
    echo "${ZABBIX_NAME} mysql.error.info '${msginfo}'">>${DATA_FILE}
    f_send_msg "${msginfo}" 
  fi  
fi
ErrSize=`ls -l ${logfile}|awk '{print $5}'`
##如果errlog 超过5M,则清空
if [ ${ErrSize} -gt 5242880 ]; then
  cp ${logfile} ${logfile}.old.bak
  msginfo="${logfile}文件超过5M,重新置0."
  >${logfile}
fi
cp ${logfile} ${baklogfile}

}

function f_slow_sqlfile_deal()
{
 monslow_file=$1 
 daystr=`date +%Y%m%d`
 hourstr=`date +%H` 
 oldtime=`cat ${flagfile}`
 if [ "${oldtime}" = "" -o "${oldtime}" != "${daystr}" ]; then 
   if [ "${hourstr}" = "00" ]; then

    #echo "------------------------$host $ip------------------------"                            >$top_slow_log
    #$mysql_dir/bin/mysqldumpslow -t $top_n $mysql_data_dir/${slowSqlFileName}|egrep -A2 $keep_user >>$top_slow_log
    #$mysql_dir/bin/mysqldumpslow -t $top_n $mysql_data_dir/${slowSqlFileName} >>$top_slow_log
    #echo  
    #cat $mysql_data_dir/$host-slow.log >>$mysql_data_dir/$host-slow.log_bak
    ##暂时修改为如果超过200M，则备份后清空，以防过大导致问题.    
    SLOWFileSize=209715200 
    slowfilesize=`ls -l ${monslow_file}|awk '{print $5}'`
    if [ ${slowfilesize} -gt ${SLOWFileSize} ]; then
      cat ${monslow_file} >${monslow_file}_bak
      echo >${monslow_file}
    fi
    #cat ${monslow_file} >${monslow_file}_bak
    #echo >${monslow_file} 
    #echo "${daystr}" > ${flagfile}
  fi
fi
}

function f_mysql_currconn_check()
{
########################################################################################
##
##脚本名:Mysql 当前连接数和配置最大连接数比较
## 说明:max_connections- curr_connections <10 ,则告警，说明当前配置连接数不足
##show processlist会占用一个进程数故实际判断为11
########################################################################################
mysqldir=$1
dbuser=$2
dbpwd=$3
socket=$4
curconn=`${mysqldir}/bin/mysql -u"$dbuser" $dbpwd -S $socket -s -e "show processlist"|wc -l|sed 's/^ //;s/ $//;s/^[[:space:]]*//g'`
tmp_maxconn=`${mysqldir}/bin/mysql -u"$dbuser" $dbpwd -S $socket -s -e "show variables like 'max_connections'"|awk '{print $2}'`
maxconn=`echo ${tmp_maxconn}|sed 's/^ //;s/ $//;s/^[[:space:]]*//g'`

###echo "得到当前mysql连接数出错得到值为${curconn},请手工检查(DB可能繁忙或者无法登陆)." >/tmp/tttt
if [ "${curconn//[0-9]/}" != "" ]; then
  msginfo="得到当前mysql连接数出错得到值为${curconn},请手工检查(DB可能繁忙或者无法登陆)."
  echo "${ZABBIX_NAME} mysql.max.connected.info '${msginfo}'">>${DATA_FILE}
  f_send_msg "${msginfo}"
  return 1
fi

if [ "${maxconn//[0-9]/}" != "" ]; then
  msginfo="查看mysql系统配置最大连接数出错,得到值为${maxconn},请手工检查(DB可能繁忙或者无法登陆)."
  echo "${ZABBIX_NAME} mysql.max.connected.info '${msginfo}'">>${DATA_FILE} 
  f_send_msg "${msginfo}"  
  return 1
fi

mincur=`echo "(${maxconn} - ${curconn})" | bc`
echo "${ZABBIX_NAME} mysql.curr.connected.info ${curconn}">>${DATA_FILE}
msginfo="mysql.curr.connected.info=${curconn}"
f_send_msg "${msginfo}" 

#echo "mysql配置max_connections减去当前连接数(${maxconn}-${curconn}=${mincur})小于11,请检查是否需要增加连接数"
if [ -z "${mincur//[0-9]/}" -a ${mincur} -lt 11 ]; then
  msginfo="mysql配置max_connections减去当前连接数(${maxconn}-${curconn}=${mincur})小于11,请检查是否需要增加连接数"
  echo "${ZABBIX_NAME} mysql.max.connected.info '${msginfo}'">>${DATA_FILE}
  f_send_msg "${msginfo}" 
 fi

}

function send_msg_zabbix()
{
##判断,如果无对应指标，则上报为NULL或者OK.
echo "############`date +%Y%m%d" "%X`############################"  >> $LOG_FILE
[ `grep -w mysql.slave.conf.err.info ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] && echo "${ZABBIX_NAME} mysql.slave.conf.err.info 0">>${DATA_FILE}
[ `grep -w mysql.slave.Seconds.behind.master ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] && echo "${ZABBIX_NAME} mysql.slave.Seconds.behind.master 9">>${DATA_FILE}
[ `grep -w mysql.error.info ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] && echo "${ZABBIX_NAME} mysql.error.info 0">>${DATA_FILE}
[ `grep -w mysql.monitor.conf.err.info ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] &&  echo "${ZABBIX_NAME} mysql.monitor.conf.err.info 0">>${DATA_FILE}
[ `grep -w mysql.max.connected.info ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] && echo  "${ZABBIX_NAME} mysql.max.connected.info 0">>${DATA_FILE}
[ `grep -w mysql.curr.connected.info ${DATA_FILE}|grep -v grep |wc -l` -lt 1 ] && echo "${ZABBIX_NAME} mysql.curr.connected.info 9">>${DATA_FILE}
cat ${DATA_FILE} >> $LOG_FILE
if [ -s ${DATA_FILE} ]; then
   ${ServerReport} -vv -z ${ServerActive} -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
   echo  -e "Successfully executed $COMMAND_LINE" >>$LOG_FILE   
else
   echo "Error in executing $COMMAND_LINE" >> $LOG_FILE
fi
echo "######################`date +%Y%m%d" "%X`##END################" >> $LOG_FILE
rm -f $DATA_FILE
	}

########################################  main ######################################
##监控需要的信息，my.cnf位置.
##2.登陆mysql的用户名和密码.
##3.对应Mysql的角色，Master or slave
##4.如果同步 异常是否修复 auto,最大延迟时间.
##5.如果有告警是否发送告警信息.
##6.告警日志文件保存位置.
##7.
###2010-12-23 增加了判断err文件超过5M则重新置0，以防copy文件导致磁盘IO,影响业务. 
###2011-05-13 修正了判断同步延迟超过预设值的告警   
###2011-06-08 增加了最大连接数的检查，约定系统配置最大连接数-当前连接数<11告警 
###2011-06-09 修复了slackware下面提取最大数空格问题  
##2012-08-30 修改为zabbix方式上报
#set -x
ServerActive=113.31.16.198
ServerReport=/usr/local/zabbix/bin/zabbix_sender
LogFileSize=10485760
uuid=$$

curdir=`dirname $0`
if [ $curdir = '.' ];then
   curdir=`pwd`
fi
paradir=$curdir

tmpdir="${curdir}/tmp"
if [ ! -d ${tmpdir} ]; then
  mkdir -p ${tmpdir}
fi
if [ ! -d ${curdir}/log ]; then
  mkdir -p ${curdir}/log
fi

LOG_FILE="${curdir}/log/mysql_log_sender.log"
if [ -f ${LOG_FILE} ]; then
  logfilesize=`ls -l ${LOG_FILE}|awk '{print $5}'`
  if [ ${logfilesize} -gt ${LogFileSize} ]; then
    >${LOG_FILE}
  fi
fi
DATA_FILE=${tmpdir}/result_mysqlmon_${uuid}
if [ -s ${DATA_FILE} ]; then
   > ${DATA_FILE}
fi

##获取本机IP
ethnum=`/sbin/ifconfig|grep eth|wc -l`
if [ ${ethnum} -gt 1 ]; then
  ip_inner=`/sbin/ifconfig eth1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
else
  ethname=`/sbin/ifconfig|grep eth|awk '{print $1}'|sed 's/^ //;s/ $//;s/[[:space:]]*//g'`
  ip_inner=`/sbin/ifconfig ${ethname} 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
fi
ip=${ip_inner}

ZABBIX_NAME=${ip}

warnfile=${curdir}/log/mysql_monitor_err.log
##DBBASE | /etc/my.cnf  | monitor     | monitor@mysql  | Y    | slave | auto | 3000
parafile=${paradir}/etc/mysql_mon.conf	
if [ ! -f ${parafile} ]; then
  echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${errinfo}">>${DATA_FILE}
  f_send_msg "${errinfo}"
  ##上报
  send_msg_zabbix
  exit 1
fi

if [ ! -f ${ServerReport} ]; then
  msginfo="${ServerReport}不存在，无法上报执行，退出. `date`"
  echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${msginfo}">>${DATA_FILE}
  f_send_msg "${msginfo}"
  ##上报
  send_msg_zabbix
  exit 1
fi

##把对应的行传如。调用解析，赋值，然后判断。每行一条记录.
cat ${parafile} |grep -v "^#"|grep  "^DBBASE" >/tmp/mysql_agent_montor.tmp
while read moncmdline
do
  #echo "monline: ${moncmdline}"
  ##根据信息循环提取并执行检查.
  f_set_parmeter  "${moncmdline}"
  ##检查同步信息
  if [ "${mysqlrole}" = "SLAVE" -o "${mysqlrole}" = "slave"  ]; then
    f_slave_status ${mysqldir} ${mysquser} ${mysqluserpwd} ${mysqlsock} ${slaveauto} ${delaynum}
  fi
  ##检查当前连接数
  f_mysql_currconn_check ${mysqldir} ${mysquser} ${mysqluserpwd} ${mysqlsock}
  ##检查错误日志
  f_mysql_errinfo ${mysqllogfile}
  ##慢速SQL
  ##慢速SQL
  if [ "${monslow_file}" != "" ]; then 
    if [ -f ${monslow_file} ]; then
  	#flagfile=/tmp/slow_file_date
  	f_slow_sqlfile_deal ${monslow_file}
    fi
  fi
  
done < /tmp/mysql_agent_montor.tmp

###处理完毕后，发送上报.
 send_msg_zabbix
##处理完毕.删除临时文件.
rm -f /tmp/mysql_agent_montor.tmp

