#!/bin/bash
#
mysql_pid=$(ps -ef |grep mysql |egrep -v "zabbix|grep|-uroot" | wc -l)
if [ ! ${mysql_pid} -eq 0 ]; then
	echo "MySQL is Running.."
else
	echo "MySQL is Stopped.."
	/etc/init.d/mysqld start
fi
