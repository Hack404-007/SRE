#!/bin/bash

export SCRIPT_NAME="$0"
curdir=`dirname $0`
if [ $curdir = '.' ];then
  curdir=`pwd`
fi
mkdir -p ${curdir}/{logs,tmp}
LOG_FILE="${curdir}/logs/sendsms.log"
TMPFILE="${curdir}/tmp/msg_tmp.log"

#if [ $# -ne 1 ]; then
if [ "$#" -ne 1 -a "$#" -ne 2 ];then
  echo "INPUT ERR. eg:${SCRIPT_NAME} telelphone msgtitle msgcontent"
  exit 1
fi
#get ipaddress
HOSTIP=`/sbin/ip -4 addr | /bin/awk '/ global /{print $2;exit}' | /bin/sed  's/\/.*//'`


CURL=/usr/bin/curl
T_DATE="`date +%F' '%T`"

#       夏伟       蒙涛        黄伟斌      白林喜      龚火金      王兴卫      刘华        魏宏武      许建刚
Phone="13682410360,13265572541,13632530190,13428936408,13554873700,13267079858,18565694207,18938678665,13480758365"

echo $2 |  egrep  '[^0-9,]'
test "$?" == 1 && Phone=${Phone},"$2"


MSG1=$1
MSG1="【云之讯】${T_DATE}:${HOSTIP} ${MSG1} !please check it !"
echo "${MSG1}"
echo "${MSG1}">${TMPFILE}
_data=`/usr/bin/iconv -f utf-8 -t gbk ${TMPFILE}`
datafront="OperID=yzxw3&OperPass=yzx7766&SendTime=&ValidTime=&AppendID=667798&DesMobile=${Phone}&Content="
data=${datafront}${_data}
echo "$data" 
SENDSTR="curl -d '${data}' http://221.179.180.158:9007/QxtSms/QxtFirewall"

eval "${SENDSTR}"
result=$?

if [ ${result} -eq 0 ]; then
 echo  -e  "#######SUCESS!########$T_DATE###############\n$Phone$MSG1$MSG2"  >>  ${LOG_FILE}
else
 echo  -e  "######ERROR:${result}#########$T_DATE###############\n$Phone$MSG1$MSG2"  >>   ${LOG_FILE}
fi
