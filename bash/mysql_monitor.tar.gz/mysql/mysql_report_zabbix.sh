#! /bin/sh
export PATH='/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin'
function f_set_parmeter()
{
  local monlst="$1"
  ##DBBASE1 | /etc/my.cnf  | /tmp/mysql.sock | root     | rootpwd  | Y    | slave | auto | 300
  #echo "INPUT: ###${monlst}###"
  mysqlsock=`echo ${monlst}     |awk -F"|" '{print $3}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysquser=`echo ${monlst}      |awk -F"|" '{print $4}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'` 
  mysqlpwd="`echo ${monlst}     |awk -F"|" '{print $5}' |sed 's/^ //;s/ $//;s/[[:space:]]*//g'`" 
  ####################################
  ##echo  "hello world" | tr "[a-z]" "[A-Z]"  
 #mysqlrole=`echo "${mysqlroletmp}" | tr "[a-z]" "[A-Z]"`  
}

function send_msg_zabbix()
{
##判断,如果无对应指标，则上报为NULL或者OK.
echo "############`date +%Y%m%d" "%X`############################"  >> $LOG_FILE
if [ -s ${DATA_FILE} ]; then   
    tmp_file=${DATA_FILE}.tmp
    echo ${ZABBIX_NAME}
    sed -i -r "s/localhost/${ZABBIX_NAME}/g" ${DATA_FILE}
    cat ${DATA_FILE} >> $LOG_FILE
    grep -v "^#" ${DATA_FILE} > ${tmp_file}
   ${ServerReport} -vv -z ${ServerActive} -i $tmp_file 2>>$LOG_FILE 1>>$LOG_FILE
   echo  -e "Successfully executed $COMMAND_LINE" >>$LOG_FILE   
else
   echo "Error in executing $COMMAND_LINE" >> $LOG_FILE
fi
echo "######################`date +%Y%m%d" "%X`##END################" >> $LOG_FILE
rm -f ${tmp_file} 
rm -f $DATA_FILE
}

########################################  main ######################################
#主要监控mysql的性能指标并上报zabbix,
#修改原来的mysqlreport脚本进行处理.该脚本使用perl进行操作，如有必须安装相关DBI，DBD rpm组件.
#执行该脚本需要在mysql中增加以下权限
##grant SUPER,SHOW DATABASES,REPLICATION SLAVE,PROCESS,REPLICATION CLIENT on *.* to 'monitor'@'localhost' identified by 'monitor@mysql'
#需要安装zabbix客户端且必须安装在/usr/local/zabbix
##默认5分钟上报一次，输入参数需要user,pwd host --socket, relative 300 zabbix_file
#perl mysqlreport  --user user --password pwd --host localhost --socket /tmp/mysql.sock --relative 30 --report-count 1 --zbfile='/usr/local/monagent/monmysql/tmp/t.txt'
curdir=`dirname $0`
if [ $curdir = '.' ];then
   curdir=`pwd`
fi
uuid=$$
sleep 1
ServerActive=10.10.16.198
ServerReport=/usr/local/zabbix/bin/zabbix_sender
mysqlreport=${curdir}/bin/mysqlreport_zabbix
hostip="10.10.201.63"
LogFileSize=10485760
splittime=301

tmpdir="${curdir}/tmp"
[ ! -d ${tmpdir} ] && mkdir -p ${tmpdir}
[ ! -d ${curdir}/log ] && mkdir -p ${curdir}/log

LOG_FILE="${curdir}/log/mysql_Performance_report.log"
if [ -f ${LOG_FILE} ]; then
  logfilesize=`ls -l ${LOG_FILE}|awk '{print $5}'`
  [ ${logfilesize} -gt ${LogFileSize} ] &&  >${LOG_FILE}
fi
DATA_FILE=${tmpdir}/result_Performance_${uuid}
[ -s ${DATA_FILE} ] &&  > ${DATA_FILE}

##获取本机IP
ethnum=`/sbin/ifconfig|grep eth|wc -l`
if [ ${ethnum} -gt 1 ]; then
  ip_inner=`/sbin/ifconfig eth1 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
else
  ethname=`/sbin/ifconfig|grep eth|awk '{print $1}'|sed 's/^ //;s/ $//;s/[[:space:]]*//g'`
  ip_inner=`/sbin/ifconfig ${ethname} 2>/dev/null |grep "inet addr:"|awk -F ":" '{ print $2 }'|awk '{ print $1 }'`
fi
ZABBIX_NAME=${ip_inner}

parafile=${curdir}/etc/mysql_mon.conf	
if [ ! -s ${parafile} ]; then
  echo "${ZABBIX_NAME} mysql.monitor.conf.err.info ${errinfo}">>${DATA_FILE}
  echo  "${errinfo}"  
  exit 1
fi
if [ ! -f ${ServerReport} ]; then
  msginfo="${ServerReport}不存在，无法上报执行，退出. `date`"
  exit 1
fi

if [ ! -f ${mysqlreport} ]; then
  msginfo="${ServerReport}不存在，无法上报执行，退出. `date`"
  exit 1
fi

##把对应的行传如。调用解析，赋值，然后判断。每行一条记录.
cat ${parafile} |grep -v "^#"|grep  "^DBBASE" >/tmp/mysql_agent_montor.tmp
while read moncmdline
do
  #echo "monline: ${moncmdline}"
  ##根据信息循环提取并执行检查.
  f_set_parmeter  "${moncmdline}"
  ##执行
  /usr/bin/perl ${mysqlreport}  --user ${mysquser} --password ${mysqlpwd} --host ${hostip} --socket ${mysqlsock} --relative ${splittime} --report-count 1 --zbfile ${DATA_FILE}
  reportnum=`cat ${DATA_FILE}|wc -l`
  if [ ${reportnum} -gt 2 ]; then
   send_msg_zabbix
  fi
  
done < /tmp/mysql_agent_montor.tmp
##处理完毕.删除临时文件.
rm -f /tmp/mysql_agent_montor.tmp

