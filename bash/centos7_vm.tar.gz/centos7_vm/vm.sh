#!/bin/bash
#

COBBER_URL=http://172.16.5.49/cobbler/ks_mirror/CentOS7-x86_64/
VIRT_EXEC=/usr/bin/virt-install
VM_RAM=8192
VM_CPU=4
NET_PRE=206
IP_START=50
j=11
for i in $(seq 1 8); do
	if [ $j -lt 16 ]; then
   		et=`printf %x $j`
   		eth=0${et}
	else
   		eth=`printf %x $j`
 	fi
	k=`printf %x $NET_PRE`

	disk=$(lvdisplay | grep "LV Path" | awk '{print $NF}'| grep "CentOS0${i}")
	VIR_NAME=$(lvdisplay | grep "LV Path" | awk '{print $NF}'| grep "CentOS0${i}" | awk -F "/" '{print $NF}')
	IP=$((i+${IP_START}))

	echo "${VIRT_EXEC} --name ${VIR_NAME}_${NET_PRE}_${IP} --ram ${VM_RAM} --disk ${disk} --vcpus ${VM_CPU} --os-type linux --os-variant rhel7 --network bridge=br0 --network bridge=br1,model=virtio,mac=00:21:f6:${k}:${eth}:02 -l ${COBBER_URL} --vnc --vnclisten=0.0.0.0"

echo " "

	echo "cobbler system add --name=${VIR_NAME}_${NET_PRE}_${IP}  --profile=CentOS7.4-x86_64  --mac=00:21:f6:${k}:${eth}:02  --ip-address=10.10.${NET_PRE}.${IP} --subnet=255.255.254.0 --netboot-enabled=1 --static=1"
echo " "

	j=$((j+1))

done
