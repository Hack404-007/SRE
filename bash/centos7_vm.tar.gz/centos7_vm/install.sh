#!/bin/bash
# Author by: Tommy
# Date : 2017.08.15
# version: 1.1.2


int='\033[94m
             _                        _         _
  __ _ _   _| |_ ___  _ __ ___   __ _| |_ ___  | | ____   ___ __ ___
 / _` | | | | __/ _ \| |_ ` _ \ / _` | __/ _ \ | |/ /\ \ / / /_ ` _ \
| (_| | |_| | || (_) | | | | | | (_| | ||  __/ |   <  \ V /| | | | | |
 \__,_|\__,_|\__\___/|_| |_| |_|\__,_|\__\___| |_|\_\  \_/ |_| |_| |_|

\033[0m'

echo -e "$int"
echo -e "\e[1;32m---------------------------------------------------------------------- \e[0m"

CurDir=$(dirname $0)
[ "$CurDir"  == '.' ] && CurDir=$(pwd)

case "$1" in
	lvm)
	cd ${CurDir} && sh lvm.sh
	;;
	kvm)
	cd ${CurDir} && sh kvm.sh
	;;
	vm)
	cd ${CurDir} && sh vm.sh
	;;
	*)
	echo " "
	echo -e "\e[1;32m !!!!!! TIPS !!!!!! \e[0m"
	echo -e "\e[1;32m Usage:${basename} $0 ( lvm|kvm|vm )\e[0m"
	echo " "
	exit 1
esac
exit 1
