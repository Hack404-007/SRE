#!/bin/bash
#

echo -e "\e[1;32m##################################################### \e[0m"
echo "IPADDR=172.16.1.00"
echo "NETMASK=255.255.255.0"
echo "GATEWAY=172.16.1.1"
echo "DNS1=114.114.114.114"
echo "DNS2=8.8.8.8"
echo -e "\e[1;32m##################################################### \e[0m"
echo " "
read -p "Make Sure The Configuration File of Network  is Correct [y/Y|N/n]:" choice

case ${choice} in
	y|Y)
	;;
	n|N)
	exit 0
	;;
	*)
	echo "Input Error.."
	exit 0
	;;
esac

#define network arguments

INTER_IF1=em1
INTER_IF2=em2

INTER_BR0_IP=$(hostname -I | awk '{print $1}')
INTER_RB0_NET=`ifconfig  ${INTER_IF1} | grep "netmask" | awk '{print $4}'`
INTER_BR0_GW=`route -n | grep "${INTER_IF1}" | grep "UG" | awk '{print $2}'`
DNS1='114.114.114.114'
DNS2='8.8.8.8'

INTER_BR1_IP=$(hostname -I | awk '{print $2}')
INTER_RB1_NET=`ifconfig  ${INTER_IF2} | grep "netmask" | awk '{print $4}'`

NETWORK_DIR='/etc/sysconfig/network-scripts'

cp ${NETWORK_DIR}/ifcfg-${INTER_IF1} ${NETWORK_DIR}/ifcfg-br0
cp ${NETWORK_DIR}/ifcfg-${INTER_IF2} ${NETWORK_DIR}/ifcfg-br1

SET_BRG()
{
##########
# ifcfg-br0
echo "BRIDGE=br0" >> ${NETWORK_DIR}/ifcfg-${INTER_IF1}
sed -i "/IPADDR=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF1}
sed -i "/NETMASK=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF1}
sed -i "/GATEWAY=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF1}
sed -i "/DNS1=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF1}
sed -i "/DNS2=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF1}

sed -i 's/TYPE=Ethernet/TYPE=Bridge/g' ${NETWORK_DIR}/ifcfg-br0
sed -i "s/DEVICE=${INTER_IF1}/DEVICE=br0/g" ${NETWORK_DIR}/ifcfg-br0
sed -i "/^NAME=${INTER_IF1}/d" ${NETWORK_DIR}/ifcfg-br0
sed -i "/^UUID=.*/d" ${NETWORK_DIR}/ifcfg-br0
#echo "IPADDR=${INTER_BR0_IP}" >> ${NETWORK_DIR}/ifcfg-br0
#echo "NETMASK=${INTER_RB0_NET}" >> ${NETWORK_DIR}/ifcfg-br0
#echo "GATEWAY=${INTER_BR0_GW}" >> ${NETWORK_DIR}/ifcfg-br0
#echo "DNS1=${DNS1}" >> ${NETWORK_DIR}/ifcfg-br0
#echo "DNS2=${DNS2}" >> ${NETWORK_DIR}/ifcfg-br0
#########

#########
# ifcfg-br1
echo "BRIDGE=br1" >> ${NETWORK_DIR}/ifcfg-${INTER_IF2}
sed -i "/IPADDR=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF2}
sed -i "/NETMASK=.*/d" ${NETWORK_DIR}/ifcfg-${INTER_IF2}

sed -i 's/TYPE=Ethernet/TYPE=Bridge/g' ${NETWORK_DIR}/ifcfg-br1
sed -i "s/DEVICE=${INTER_IF2}/DEVICE=br1/g" ${NETWORK_DIR}/ifcfg-br1
sed -i "/^NAME=${INTER_IF2}/d" ${NETWORK_DIR}/ifcfg-br1
sed -i "/^UUID=.*/d" ${NETWORK_DIR}/ifcfg-br1
#echo "IPADDR=${INTER_BR1_IP}" >> ${NETWORK_DIR}/ifcfg-br1
#echo "NETMASK=${INTER_RB1_NET}" >> ${NETWORK_DIR}/ifcfg-br1
########
echo -e "\e[1;32m 6) Set bridge network OK.\e[0m"
sleep 2
echo "Please check ifcfg-* setting and restart network service.."
}

DISABLE_IPTABLES()
{
systemctl stop firewalld.service
systemctl disable firewalld.service
yum install iptables-services -y
systemctl enable iptables
systemctl start iptables
iptables -F
service iptables save
echo -e  "\e[1;32m 1) Disable iptables OK.\e[0m"
sleep 2
}

CHECK_VM()
{
if ! egrep  -E -o  --color '(vmx|svm)' /proc/cpuinfo > /dev/null; then
	echo "OH,your system does not support virtualization !\nPlease modify the BIOS virtualization options"
else
	echo -e  "\e[1;32m 2) system has already supported virtualization.\e[0m"
fi
}

INSTALL_KVM()
{
#echo "Install kvm for softeare."
yum install qemu-kvm qemu-img virt-manager libvirt libvirt-python libvirt-client virt-install virt-viewer bridge-utils -y

#echo "load kvm kenerl mode"
modprobe kvm
modprobe kvm_intel
if lsmod | grep kvm > /dev/null; then
	echo  -e "\e[1;32m 3) kvm for kernel mode load success.\e[0m"
	sleep 2
fi
#echo "Start libvirtd."

if test $? -eq 0; then
	echo -e "\e[1;32m 4) start libvirtd success.\e[0m"
	sleep 2
	systemctl enable libvirtd
	systemctl start libvirtd
	
fi
#echo "Install X Window System"
yum install "@X Window System" xorg-x11-xauth xorg-x11-fonts-* xorg-x11-utils -y
echo -e "\e[1;32m 5) Install Window System OK.\e[0m"
}

main()
{
DISABLE_IPTABLES
CHECK_VM
INSTALL_KVM
SET_BRG
}
main
